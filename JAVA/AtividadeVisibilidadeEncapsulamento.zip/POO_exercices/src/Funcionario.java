import java.util.Date;

public class Funcionario {

	private String Nome;
	private Date Data_admissao;
	private double Salario;
	private static int Identificador = 0;
	private Date Data_Atual = new Date();
	


	public String getNome() {
		return Nome;
	}
	
	
	
	public void setNome(String Nome) {
		Funcionario.Identificador = Identificador++;
		this.Nome = Nome;
	}
	
	
	public Date getData_admissao() {
		return Data_admissao;
	}
	
	
	public void setData_admissao(Date Data_admissao) {
		if (Data_Atual.compareTo(Data_admissao) < 0) {
			System.out.println("Data de admissão invalida, não é possivel adicionar um valor futuro");
			
		}
		else 
		{
		this.Data_admissao = Data_admissao;
		}
	}
	
	
	public double getSalario() {
		return Salario;
	}
	
	
	public void setSalario(double Salario) {
		if(Salario < 1320) {
			System.out.println("Coe, trabalha análogo a escravidão não pode em");
		}
		else {
		this.Salario = Salario;}
	}
	
	public int getIdentificador() {
		return Identificador;
	}


public static void main(String[] args) {
// TODO Auto-generated method stub

}

}

