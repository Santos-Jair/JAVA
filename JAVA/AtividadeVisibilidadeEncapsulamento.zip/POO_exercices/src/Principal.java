
import java.text.ParseException;
import java.text.SimpleDateFormat;


public class Principal {

	public static void main(String[] args) throws ParseException {
	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	
	
	Funcionario F1 = new Funcionario();
	{
		F1.setNome("Augusto");
		F1.setData_admissao(sdf.parse("07/06/2020"));
		F1.setSalario(1320.00);
	}
	Funcionario F2 = new Funcionario();
	{
		F2.setNome("Bianca");
		F2.setData_admissao(sdf.parse("10/12/2010"));
		F2.setSalario(5500.00);
	}
	Funcionario F3 = new Funcionario();
	{
		F3.setNome("Cairo");
		F3.setData_admissao(sdf.parse("03/19/2023"));
		F3.setSalario(900.00);
	}
	
	}

}
