
public class Relogio {
	
	
	
	public static void Inicializar(int Hora, int Minuto, int Segundo) {
		if(1>=Hora && 1>=Minuto && 1 >=Segundo) {
			System.out.println(+Hora+" Hora   |"+Minuto+" Minuto   |"+Segundo+" Segundo");
		}
		else if(1>=Minuto && 1 >=Segundo) {
			System.out.println(+Hora+" Horas |"+Minuto+" Minuto   |"+Segundo+" Segundo");
		}
		else if(1 >=Segundo) {
			System.out.println(+Hora+" Horas  |"+Minuto+" Minutos |"+Segundo+" Segundo");
		}
		else {
		System.out.println(+Hora+" Horas |"+Minuto+" Minutos |"+Segundo+" Segundos");
		}
	}
	public static void Inicializar(int Hora, int Minuto) {
		Inicializar(Hora, Minuto, 1);
	}
	
	public static void Inicializar(int Hora) {
		Inicializar(Hora, 1, 1);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
