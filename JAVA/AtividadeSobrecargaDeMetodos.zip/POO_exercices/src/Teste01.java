
public class Teste01 {
	
	

	public static void main(String[] args) {
		
		Funcionario.Tirar_ferias();
		Funcionario.Tirar_ferias(4);
		Funcionario.Tirar_ferias(60);
		Funcionario.Tirar_ferias(90);
		System.out.println("====================================================\n");
		
		Relogio.Inicializar(12,30,15);
		Relogio.Inicializar(9,32);
		Relogio.Inicializar(13);
		Relogio.Inicializar(19);
		
	}
}
