package Polimorfico;

public class Produto {
	private String Nome, Descrição;
	private double Valor;
	
	
	public Produto(String nome, String descrição, double valor) {
		super();
		this.Nome = nome;
		this.Descrição = descrição;
		this.Valor = valor;
	}
	
	@Override
	public String toString() {
		return "Informações do produto referido\n"
				+ "Nome:" +this.Nome+"\n"
				+ "Descrição: " +this.Descrição+"\n"
				+ "Valor: R$"+this.Valor;
	}
	
	public boolean equals (Produto P) {
	if (this.Nome == P.Nome && this.Descrição == P.Descrição && this.Valor == P.Valor) {
		return true;
	} else {
		return false;
	}
	}
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public String getDescrição() {
		return Descrição;
	}
	public void setDescrição(String descrição) {
		Descrição = descrição;
	}
	public double getValor() {
		return Valor;
	}
	public void setValor(double valor) {
		Valor = valor;
	}

}
