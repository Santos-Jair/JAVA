package Polimorfico;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Menu {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Menu Example");
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenuItem openItem = new JMenuItem("Open");
        JMenuItem saveItem = new JMenuItem("Save");
        JMenuItem exitItem = new JMenuItem("Exit");

        fileMenu.add(openItem);
        fileMenu.add(saveItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);

        // Adicionando botões personalizados ao menu
        JButton customButton1 = new JButton("Custom Button 1");
        JButton customButton2 = new JButton("Custom Button 2");

        fileMenu.add(customButton1);
        fileMenu.add(customButton2);

        menuBar.add(fileMenu);

        frame.setJMenuBar(menuBar);
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        exitItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        // Ação personalizada para o primeiro botão
        customButton1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                metodoPersonalizado1();
            }
        });

        // Ação personalizada para o segundo botão
        customButton2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                metodoPersonalizado2();
            }
        });
    }

    // Métodos personalizados que serão chamados ao clicar nos botões personalizados
    private static void metodoPersonalizado1() {
        System.out.println("Botão Personalizado 1 foi clicado.");
    }

    private static void metodoPersonalizado2() {
        System.out.println("Botão Personalizado 2 foi clicado.");
    }
}
