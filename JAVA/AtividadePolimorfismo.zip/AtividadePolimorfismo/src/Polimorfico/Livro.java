package Polimorfico;

public class Livro extends Produto{
	private String Autores, Editora;
	private int ISBN;
	
	public Livro(String nome, String descrição, double valor, String autores, String editora, int iSBN) {
		super(nome, descrição, valor);
		Autores = autores;
		Editora = editora;
		ISBN = iSBN;
	}
	
	public boolean equals (Livro L) {
		if (this.getNome() == L.getNome() && this.getDescrição() == L.getDescrição() && this.getValor() == L.getValor() && this.Autores == L.Autores && this.Editora == L.Editora && this.ISBN == L.ISBN) {
			return true;
		} else {
			return false;
		}
		}
	
	public String toString() {
		return "Informações do livro referido\n"
				+ "Nome: " +this.getNome()+"\n"
				+ "Descrição: " +this.getDescrição()+"\n"
				+ "Valor: R$"+this.getValor()+"\n"
				+ "Autor: "+this.getAutores()+"\n"
				+ "Editora: " +this.getEditora()+"\n"
				+ "ISBN: "+this.getISBN();
	}

	public String getAutores() {
		return Autores;
	}

	public void setAutores(String autores) {
		Autores = autores;
	}

	public String getEditora() {
		return Editora;
	}

	public void setEditora(String editora) {
		Editora = editora;
	}

	public int getISBN() {
		return ISBN;
	}

	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}
	
	
	
	

}
