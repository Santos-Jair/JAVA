package Polimorfico;

import java.util.Scanner;

public class teste {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		int Controle = 99, Indice = 0;
		
		Produto[] P = new Produto[1000];
		
		Scanner Sc = new Scanner(System.in);
		
		
		
		while(Controle != 0) {
			
			System.out.print("##-- Menu de produtos --##\n\n");
			System.out.print("|-----------------------------|\n");
			System.out.print("| Opção 1 - Cadastrar Produto |\n");
			System.out.print("| Opção 2 - Listar Produtos   |\n");
			System.out.print("| Opção 3 - Cadastrar Livro   |\n");
			System.out.print("| Opção 4 - Listar Livros     |\n");
			System.out.print("| Opção 5 - imprimir tudo     |\n");
			System.out.print("| Opção 0 - Sair              |\n");
			System.out.print("|-----------------------------|\n");
			System.out.print("Digite uma opção: ");
			
			Controle = Sc.nextInt();
			
			switch (Controle) {
			
			case (1):
				System.out.print("Digite o nome do produto: ");
				Sc.nextLine();
				String Nome = Sc.nextLine();
				System.out.print("Digite o categoria do produto: ");
				
				String Categoria = Sc.nextLine();
				System.out.print("Digite o valor do produto: ");
				
				double Valor = Sc.nextDouble();
				
				P[Indice] = new Produto (Nome,Categoria,Valor);
				
				Indice++;
				
				System.out.println("Novo produto cadastrado");
			break;
			case (2):
				for (int i = 0; i >= Indice; i++ ) {
					if(P[Indice] instanceof Produto)
					System.out.println(P[Indice].toString());
				}
			break;
			case (3):
				System.out.print("Digite o nome do Livro: ");
				Sc.nextLine();
				String NomeL = Sc.nextLine();
				System.out.print("Digite o categoria do Livro: ");
				String CategoriaL = Sc.nextLine();
				
				System.out.print("Digite o valor do Livro: ");
				double ValorL = Sc.nextDouble();
				
				System.out.print("Digite o autor do Livro: ");
				String AutorL = Sc.nextLine();
				
				System.out.print("Digite a editora do Livro: ");
				
				String EditoraL = Sc.nextLine();
				
				System.out.print("Digite o categoria do Livro: ");
				int ISBN = Sc.nextInt();
				
				P[Indice] = new Livro (NomeL,CategoriaL,ValorL,AutorL,EditoraL,ISBN);
				
				Indice++;
				
				System.out.println("Novo livro cadastrado");
			break;
			case (4):
				for (int i = 0; i >= Indice; i++ ) {
					if(P[Indice] instanceof Livro)
					System.out.println(P[Indice].toString());
				}
			break;
			case (5):
				for (int i = 0; i >= Indice; i++ ) {
					
					System.out.println(P[Indice].toString());
				}
			break;
				
				
				
				
			
			}
			
			
			
		}
		

	}

}
