package Excecoes;

public class DataException extends Exception {
	
	Data d;

	public DataException() {
		
	}
	public DataException(String msg) {
		super(msg);
	}
	

	public DataException(Data d) {
		this.d = d;
	}

	public String toString() {
		Data.cont++;
		return "A "+Data.cont+"° data é invalida";
		
	}

	
	
	
}
