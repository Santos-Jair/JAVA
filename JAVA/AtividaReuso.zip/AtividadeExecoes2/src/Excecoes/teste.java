package Excecoes;

public class teste {

	
	public static void main(String[] args) {
		
		try {
		Data d = new Data(30,2,2000);
		d.ImprimeData(d);
		
		}
		catch (DataException e) {
			System.out.println(e);
		}
		try {
			Data a = new Data(15,2,2023);
			a.ImprimeData(a);
			
			}
			catch (DataException e) {
				System.out.println(e);
			}
		try {
			Data b = new Data(31,12,2020);
			b.ImprimeData(b);
			
			}
			catch (DataException e) {
				System.out.println(e);
			}
		try {
			Data c = new Data(30,2,-2000);
			c.ImprimeData(c);
			
			}
			catch (DataException e) {
				System.out.println(e);
			}
	
		
	}
}
