package Excecoes;

public class Data {
	int Dia, Mes, Ano;
	static int cont = 0;

	
	
	public void ImprimeData(Data d){
		System.out.println("A "+cont+"° data informada foi: "+d.Dia+"/"+d.Mes+"/"+d.Ano+"");
		
	}
	
	public void AtribuiDia(int n) {
		this.Dia = n;
	}
	
	
	
	public Data(int Dia, int Mes, int Ano) throws DataException {
		super();
		
		if (Mes == 1 || Mes == 3 || Mes == 5 || Mes == 7 || Mes == 8 || Mes == 10 || Mes == 12) 
		{
			if(0<= Dia && Dia <= 31 ) 
			{
			AtribuiDia(Dia);
			}
			else {
				throw new DataException();
			}
		} 
		
		else if (Mes == 4 || Mes == 6 || Mes == 9 || Mes == 11) 
		{
			if(0<= Dia && Dia <= 30 ) 
			{
			AtribuiDia(Dia);
			}
			else {
				throw new DataException();
			}
		} 
		else if (Mes == 2) 
		{
			if(0<= Dia && Dia <= 28 ) 
			{
			AtribuiDia(Dia);
			}
			else {
				throw new DataException();
			}
		} else {
			throw new DataException();
		}
		if(1<= Mes && Mes <= 12 ) 
		{
		this.Mes = Mes;
		}
		else {
			throw new DataException();
		}
		if(1 <= Ano ) 
		{
		this.Ano = Ano;
		}
		else {
			throw new DataException();
		}
	
		
	cont++;
	}
	
	



}
