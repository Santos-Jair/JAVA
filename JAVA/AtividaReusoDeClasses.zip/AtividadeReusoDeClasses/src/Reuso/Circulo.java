package Reuso;

public class Circulo extends ObjetoGeometrico{
	private int Raio;
	private int Centro;
	private double Area;
	private double Perimetro;
	
	public double CalculaArea(int Raio) {
		Area = (Math.PI *( Raio * Raio));
		return getArea();
	}
	public double CalculaPerimetro(int Raio) {
		Area = (2*Math.PI *Raio);
		return getArea();
	}
	public int getRaio() {
		return Raio;
	}
	public void setRaio(int raio) {
		Raio = raio;
	}
	public int getCentro() {
		return Centro;
	}
	public void setCentro(int centro) {
		Centro = centro;
	}
	public double getArea() {
		return Area;
	}
	public int getPerimetro() {
		return (int) Perimetro;
	}
	
	
	
	

}
