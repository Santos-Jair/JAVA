package Reuso;

public class Retangulo extends ObjetoGeometrico {
	

	public double CalculaArea(int LadoA, int LadoB) {
		Area = LadoA * LadoB;
		return Area;
	}
	
	public int CalculaPeriemtro(int LadoA, int LadoB) {
		
		Perimetro = 2*LadoA+2*LadoB;
		return Perimetro;
	}
}
