package Reuso;

public class ObjetoGeometrico {
	protected int Altura;
	protected int Largura;
	protected double Area;
	protected int Perimetro;
	
	public ObjetoGeometrico() {}
	
	public ObjetoGeometrico(int Altura, int Largura) {
		this.Altura = Altura;
		this.Largura = Largura;
		
	}
	
	public double CalculaArea(int Altura, int Largura) {
		Area = Altura * Largura;
		return Area;
	}
	
	public int CalculaPeriemtro(int Altura, int Largura) {
		Perimetro = Altura + Largura;
		return Perimetro;
	}

	public int getAltura() {
		return Altura;
	}

	public void setAltura(int altura) {
		Altura = altura;
	}

	public int getLargura() {
		return Largura;
	}

	public void setLargura(int largura) {
		Largura = largura;
	}

	public double getArea() {
		return Area;
	}

	public void setArea(int area) {
		Area = area;
	}

	public int getPerimetro() {
		return Perimetro;
	}

	public void setPerimetro(int perimetro) {
		Perimetro = perimetro;
	}
	

	

	
	

}
