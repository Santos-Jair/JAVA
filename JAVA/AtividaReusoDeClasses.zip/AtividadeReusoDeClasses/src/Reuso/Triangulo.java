package Reuso;

public class Triangulo extends ObjetoGeometrico{
	private int LadoA;
	private int LadoB;
	private int LadoC;
	public double Area;
	
	
	
	public double CalculaArea(int LadoA, int LadoB,int LadoC, int Perimetro) {
		
		int s = Perimetro/2;
		
		Area = Math.sqrt(s*(s-LadoA)*(s-LadoB)*(s-LadoC));
		return Area;
	}
	
	public int CalculaPeriemtro(int LadoA, int LadoB, int LadoC) {
		setPerimetro(LadoA + LadoB + LadoC);
		return getPerimetro();
	}

	public int getLadoA() {
		return LadoA;
	}

	public void setLadoA(int ladoA) {
		LadoA = ladoA;
	}

	public int getLadoB() {
		return LadoB;
	}

	public void setLadoB(int ladoB) {
		LadoB = ladoB;
	}

	public int getLadoC() {
		return LadoC;
	}

	public void setLadoC(int ladoC) {
		LadoC = ladoC;
	}


	
	


}
