
public class Linha_Ferroviaria {
	private String Descricao;
	private int Extensao;
	private int ID;
	private Vagao Vagao;
	private Trem Trem;
	private Locomotiva Locomotiva;
	
	Linha_Ferroviaria(){
		
	}

	public String getDescricao() {
		return Descricao;
	}

	public void setDescricao(String descricao) {
		Descricao = descricao;
	}

	public int getExtensao() {
		return Extensao;
	}

	public void setExtensao(int extensao) {
		Extensao = extensao;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public Vagao getVagao() {
		return Vagao;
	}

	public void setVagao(Vagao vagao) {
		Vagao = vagao;
	}

	public Trem getTrem() {
		return Trem;
	}

	public void setTrem(Trem trem) {
		Trem = trem;
	}

	public Locomotiva getLocomotiva() {
		return Locomotiva;
	}

	public void setLocomotiva(Locomotiva locomotiva) {
		Locomotiva = locomotiva;
	}
	
	
	
	

}
