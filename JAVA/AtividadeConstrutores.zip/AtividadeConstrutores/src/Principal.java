
public class Principal {

	public static void main(String[] args) {
		
		Vagao Vagao01 = new Vagao();
		Vagao Vagao02 = new Vagao();
		Vagao Vagao03 = new Vagao();
		
		Locomotiva Echos =  new Locomotiva();

		
		Trem Delta = new Trem(); {
			Delta.setLocomotiva(Echos);
			Delta.setVagao(Vagao01);
			Delta.setVagao(Vagao02);
			Delta.setVagao(Vagao03);
			
		}
	
		
		Linha_Ferroviaria Alpha = new Linha_Ferroviaria();
		Linha_Ferroviaria Beta = new Linha_Ferroviaria();{
			
			Beta.setTrem(Delta);
		}
		Linha_Ferroviaria Charlie = new Linha_Ferroviaria();
		
		Estacao_Ferroviaria CE = new Estacao_Ferroviaria(Alpha,Beta);
		Estacao_Ferroviaria RJ = new Estacao_Ferroviaria(Beta,Charlie);
		
		System.out.println("Estação: "+CE.getLinha_Ferroviaria());
		System.out.println("Estação: "+RJ.getLinha_Ferroviaria());
		

	
	}
}
