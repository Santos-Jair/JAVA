
public class Estacao_Ferroviaria {
	
	private char Sigla;
	private String Descricao;
	private Linha_Ferroviaria Linha_Ferroviaria;
	
	Estacao_Ferroviaria(Object Linha_Ferroviaria) {
		
		this.Linha_Ferroviaria = (Linha_Ferroviaria) Linha_Ferroviaria;
		
	}
	Estacao_Ferroviaria(Object Linha_Ferroviaria01, Object Linha_Ferroviaria02) {
		
		Linha_Ferroviaria = (Linha_Ferroviaria) Linha_Ferroviaria01;
		Linha_Ferroviaria  =  (Linha_Ferroviaria) Linha_Ferroviaria02;
		
	}

	/**
	 * @return the sigla
	 */
	public char getSigla() {
		return Sigla;
	}

	/**
	 * @param sigla the sigla to set
	 */
	public void setSigla(char sigla) {
		Sigla = sigla;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return Descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		Descricao = descricao;
	}

	/**
	 * @return the linha_Ferroviaria
	 */
	public Object getLinha_Ferroviaria() {
		return Linha_Ferroviaria;
	}

	/**
	 * @param linha_Ferroviaria the linha_Ferroviaria to set
	 */
	public void setLinha_Ferroviaria(Linha_Ferroviaria linha_Ferroviaria) {
		
		this.Linha_Ferroviaria = (Linha_Ferroviaria) linha_Ferroviaria;
	}
	
	
	

	
}
