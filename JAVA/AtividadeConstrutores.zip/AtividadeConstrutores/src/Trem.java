import java.util.Date;

public class Trem {
	private Vagao Vagao;
	private Locomotiva Locomotiva;
	private String Prefixo;
	private Date Data_Formação;
	private Estacao_Ferroviaria Estacao_Ferroviaria_Origem;
	private Estacao_Ferroviaria Estacao_Ferroviaria_Destino;
	
	Trem(){
		
	}
	
	Trem(Locomotiva Locomotiva,Vagao Vagao,Estacao_Ferroviaria Estacao_Ferroviaria_Origem, Estacao_Ferroviaria Estacao_Ferroviaria_Destino){
		this.Locomotiva = (Locomotiva) Locomotiva;
		this.Vagao = (Vagao) Vagao;
		
		//Compara(Estacao_Ferroviaria_Origem, Estacao_Ferroviaria_Destino);
		//tentei implementar um método de comparação mas falhei miseravelmente kkk
		if(Estacao_Ferroviaria_Origem != Estacao_Ferroviaria_Destino) {
			
		this.Estacao_Ferroviaria_Origem = (Estacao_Ferroviaria) Estacao_Ferroviaria_Origem;
		this.Estacao_Ferroviaria_Destino = (Estacao_Ferroviaria) Estacao_Ferroviaria_Destino;
		
		}
		else{
			System.out.println("Não é possivel selecionar estações de origem e destino iguais");
		}
		
	}
	

	/*
	private static void Compara(Object Estacao_Ferroviaria_Origem, Object Estacao_Ferroviaria_Destino) {
		if(Estacao_Ferroviaria_Origem != Estacao_Ferroviaria_Destino) {
			
			
		} else {
			
		}
		
		
	}
	*/

	public String getPrefixo() {
		return Prefixo;
	}

	public void setPrefixo(String prefixo) {
		Prefixo = prefixo;
	}

	public Date getData_Formação() {
		return Data_Formação;
	}

	public void setData_Formação(Date data_Formação) {
		Data_Formação = data_Formação;
	}

	public Object getVagao() {
		return Vagao;
	}

	public Object getLocomotiva() {
		return Locomotiva;
	}

	public Object getEstacao_Ferroviaria_Origem() {
		return Estacao_Ferroviaria_Origem;
	}

	public Object getEstacao_Ferroviaria_Destino() {
		return Estacao_Ferroviaria_Destino;
	}

	public void setEstacao_Ferroviaria_Origem(Object estacao_Ferroviaria_Origem) {
		//Compara(Estacao_Ferroviaria_Origem, Estacao_Ferroviaria_Destino);
				//tentei implementar um método de comparação mas falhei miseravelmente kkk
				if(Estacao_Ferroviaria_Origem != Estacao_Ferroviaria_Destino) {
					
				this.Estacao_Ferroviaria_Origem = (Estacao_Ferroviaria) Estacao_Ferroviaria_Origem;
				
				}
				else{
					System.out.println("Não é possivel selecionar estações de origem e destino iguais");
				}
	}

	public void setEstacao_Ferroviaria_Destino(Object estacao_Ferroviaria_Destino) {
		//Compara(Estacao_Ferroviaria_Origem, Estacao_Ferroviaria_Destino);
				//tentei implementar um método de comparação mas falhei miseravelmente kkk
				if(Estacao_Ferroviaria_Origem != Estacao_Ferroviaria_Destino) {
					
				this.Estacao_Ferroviaria_Destino = (Estacao_Ferroviaria) Estacao_Ferroviaria_Destino;
				
				}
				else{
					System.out.println("Não é possivel selecionar estações de origem e destino iguais");
				}
	}

	public void setVagao(Vagao vagao) {
		this.Vagao = vagao;
	}

	public void setLocomotiva(Locomotiva locomotiva) {
		this.Locomotiva = locomotiva;
	}
	
	
	

}
