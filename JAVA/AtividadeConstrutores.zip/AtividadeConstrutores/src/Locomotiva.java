
public class Locomotiva {
	
	private int Numero_Serie;
	private int Capacide_tracao;
	private int Comprimento;
	
	Locomotiva(){}
	
	Locomotiva(int Numero_Serie, int Capacidade_tracao, int Comprimento){
		this.Numero_Serie  =  Numero_Serie;
		this.Capacide_tracao = Capacidade_tracao;
		this.Comprimento  = Comprimento;
		
	}
	
	public int getNumero_Serie() {
		return Numero_Serie;
	}
	public void setNumero_Serie(int numero_Serie) {
		Numero_Serie = numero_Serie;
	}
	public int getCapacide_tracao() {
		return Capacide_tracao;
	}
	public void setCapacide_tracao(int capacide_tracao) {
		Capacide_tracao = capacide_tracao;
	}
	public int getComprimento() {
		return Comprimento;
	}
	public void setComprimento(int comprimento) {
		Comprimento = comprimento;
	}
	
	
	

}
