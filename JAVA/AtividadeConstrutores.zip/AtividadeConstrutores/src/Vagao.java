
public class Vagao {
	private int ID_Serial;
	private String Tipo;
	private int Capacidade_Carga;
	private int Comprimento_testeiras;
	private int Comprimento_engates;
	
	Vagao(){
		
	}
	
	Vagao(int ID_Serial, String Tipo,int Capacidade_Carga,int Comprimento_testeiras,int Comprimento_engates) {
		
		this.ID_Serial = ID_Serial;
		this.Tipo = Tipo;
		this.Capacidade_Carga = Capacidade_Carga;
		this.Comprimento_testeiras  = Comprimento_testeiras;
		this.Comprimento_engates  = Comprimento_engates;
		
	}

	public int getID_Serial() {
		return ID_Serial;
	}

	public void setID_Serial(int iD_Serial) {
		ID_Serial = iD_Serial;
	}

	public String getTipo() {
		return Tipo;
	}

	public void setTipo(String tipo) {
		Tipo = tipo;
	}

	public int getCapacidade_Carga() {
		return Capacidade_Carga;
	}

	public void setCapacidade_Carga(int capacidade_Carga) {
		Capacidade_Carga = capacidade_Carga;
	}

	public int getComprimento_testeiras() {
		return Comprimento_testeiras;
	}

	public void setComprimento_testeiras(int comprimento_testeiras) {
		Comprimento_testeiras = comprimento_testeiras;
	}

	public int getComprimento_engates() {
		return Comprimento_engates;
	}

	public void setComprimento_engates(int comprimento_engates) {
		Comprimento_engates = comprimento_engates;
	}
	
	

	

}
