package Interfaces;

public interface Motorizado {
	
	public void LigarMotor();
	public void Abstacer(int NumLitros);

}
