package Interfaces;

public abstract class TransporteTerrestre extends Transporte {

	public String Tipo;
	
	abstract public void Estacionar();

}
