package Interfaces;

public abstract class Transporte {
	public String Nome;
	public int NumeroPassageiros;
	public int VelocidadeAtual;
	
	abstract public boolean Isparado();
	

}
