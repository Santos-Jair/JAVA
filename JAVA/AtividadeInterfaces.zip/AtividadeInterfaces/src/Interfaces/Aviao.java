package Interfaces;

public class Aviao extends TransporteAereo implements Motorizado, Conduzivel {
	
	private int NumeroDeMotores;

	@Override
	public void Subir(int metros) {
		
	}

	@Override
	public void Descer(int metros) {
		
	}

	@Override
	public boolean Isparado() {
		
		return false;
	}
	
	public void Curvar (float Angulo) {
		System.out.println("Avião fazendo uma curva de "+Angulo+"º graus");
	}
	
	public void Abastecer (int NumLitros) {
		System.out.println("Avião abastecido em "+NumLitros+" Litros");
			
	}
	
	public void LigarMotor () {
		System.out.println("Ligando moteres, preparar pra decolar");
		
	}

	public int getNumeroDeMotores() {
		return NumeroDeMotores;
	}

	public void setNumeroDeMotores(int numeroDeMotores) {
		NumeroDeMotores = numeroDeMotores;
	}

	@Override
	public void Abstacer(int NumLitros) {
		// TODO Auto-generated method stub
		
	}
	
	

}
