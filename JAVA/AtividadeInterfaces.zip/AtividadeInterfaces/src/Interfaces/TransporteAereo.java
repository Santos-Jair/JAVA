package Interfaces;

public abstract class TransporteAereo extends Transporte{

	public int AltitudeAtual;
	
	abstract public void Subir(int metros);
	abstract public void Descer(int metros);
}
