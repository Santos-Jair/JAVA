package Interfaces;

public class teste {

	public static void main(String[] args) {
	
	Carro C = new Carro();
	C.setCilindrada(300);
	Bicicleta B = new Bicicleta();
	B.setNumeroRaios(36);
	Aviao A =  new Aviao();
	A.setNumeroDeMotores(4);
	
	
	C.Abastecer(55);
	C.LigarMotor();
	C.Curvar(35);
	
	
	A.Abastecer(16273);
	A.LigarMotor();
	A.Curvar(90);

	
	B.Curvar(180);
	}

}
