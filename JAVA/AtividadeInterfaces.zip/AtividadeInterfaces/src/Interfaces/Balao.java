package Interfaces;

public class Balao extends TransporteAereo {
	
	private float PesoLargada;

	@Override
	public void Subir(int metros) {
		

	}

	@Override
	public void Descer(int metros) {
		

	}

	@Override
	public boolean Isparado() {
		
		return false;
	}

	public void LargarPeso (float Peso) {
			
	}
	public void AquecerAr (float Temperatura) {
		
	}

	public float getPesoLargada() {
		return PesoLargada;
	}

	public void setPesoLargada(float pesoLargada) {
		PesoLargada = pesoLargada;
	}
}
