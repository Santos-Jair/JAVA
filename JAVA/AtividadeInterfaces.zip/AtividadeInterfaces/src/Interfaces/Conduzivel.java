package Interfaces;

public interface Conduzivel {
	default public void Curvar(float Angulo) {
		System.out.println("Curvando "+Angulo+"º Graus");
	}

}
