package Interfaces;

public class Bicicleta extends TransporteTerrestre implements Conduzivel {
	private int NumeroRaios;

	@Override
	public void Estacionar() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean Isparado() {
		// TODO Auto-generated method stub
		return false;
	}
	public void Curvar (float Angulo) {
		System.out.println("Bicileta fazendo uma curva de "+Angulo+"º graus");
			
	}
	
	public void Pedalar () {
		
	}

	public int getNumeroRaios() {
		return NumeroRaios;
	}

	public void setNumeroRaios(int numeroRaios) {
		NumeroRaios = numeroRaios;
	}

}
