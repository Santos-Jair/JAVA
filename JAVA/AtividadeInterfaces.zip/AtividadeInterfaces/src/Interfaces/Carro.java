package Interfaces;

public class Carro extends TransporteTerrestre implements Motorizado, Conduzivel {
	
	private int Cilindrada;

	@Override
	
	
	public void Estacionar() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean Isparado() {
		// TODO Auto-generated method stub
		return false;
	}

	public void Curvar (float Angulo) {
		System.out.println("Carro fazendo uma curva de "+Angulo+"º graus");
			
	}
	
	public void Abastecer (int NumLitros) {
		System.out.println("Carro abastecido em "+NumLitros+" Litros");
			
	}
	
	public void LigarMotor () {
		System.out.println("Ligando motor... Vrum vrum");
		
	}
	
	public void Embraiar() {
		
	}

	public int getCilindrada() {
		return Cilindrada;
	}

	public void setCilindrada(int cilindrada) {
		Cilindrada = cilindrada;
	}

	@Override
	public void Abstacer(int NumLitros) {
		// TODO Auto-generated method stub
		
	}
}
