package Excecoes;

import javax.swing.*;

public class Cadastro {
	private String Nome;
	private String Telefone;
	
	

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public String getTelefone() {
		return Telefone;
	}

	public void setTelefone(String telefone) {

		Telefone = telefone;
	}

	
	
	
	public Cadastro() throws IllegalArgumentException   {
		super();
		Nome = JOptionPane.showInputDialog("Insira o nome do usuario:");
		System.out.println(Nome);
		if(Nome.isBlank() || Nome.isEmpty()) {
			throw new IllegalArgumentException();
		} else {
			System.out.println("Nome: "+Nome+" Armazenado com sucesso");
		}
		Telefone = JOptionPane.showInputDialog("Informe o telefone do usuario");
		if(Telefone.isBlank() || Telefone.isEmpty()) {
			throw new IllegalArgumentException();
		} else {
			System.out.println("Telefone: "+Telefone+ " Armazenado com sucesso");
		}
		
	}

	public static void main(String[] args) {
		
		try {
			Cadastro A = new Cadastro();
		} catch(IllegalArgumentException e) {
			System.out.println("Informação Invalida");
		}
		
		
	}

}
